<?php
	/*****************
		  Function : getAuthentName
		  Parameters : 
		    $cnx : DB connection
		    $user : user id
		    &$greetings : out Civility
		    &$firstName : out first name
		    &$lastName : out last name
		  Output : Nothing
	*****************/

	function getAuthentName($cnx, $user, &$greetings, &$firstName, &$lastName) {
		$sql = "SELECT greetings, firstName, lastName FROM users WHERE id = ?";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("i", $user);
			$stmt->bind_result($greetings, $firstName, $lastName);
			if (!$stmt->execute())
				logging("ERROR", "execute failed - reason:" . $stmt->error, "getAuthentName", "dbfunctions.php");
			else {
				$stmt->fetch();

			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "getAuthentName", "dbfunctions.php");
		}

	}

	/*****************
		  Function : getEventTitle
		  Parameters : 
		    $cnx : DB connection
		    $event : event id
		    &$title : out event title
		  Output : Nothing
	*****************/

	function getEventTitle($cnx, $event, &$title) {
		$sql = "SELECT title FROM events WHERE id = ?";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("i", $event);
			$stmt->bind_result($title);
			if (!$stmt->execute())
				logging("ERROR", "execute failed - reason:" . $stmt->error, "getEventTitle", "dbfunctions.php");
			else {
				$stmt->fetch();

			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "getEventTitle", "dbfunctions.php");
		}

	}

	/*****************
		  Function : getQuestion
		  Parameters : 
		    $cnx : DB connection
		    $id : evqust id
		  Output : HTML draw question
	*****************/

	function getQuestion($cnx, $id) {
		$content = null;
		$likes = null;
		$date = null;
		$sql = "SELECT q.content AS content, e.likes AS likes, e.date AS date, e.moderation AS moderation FROM questions AS q, evqust AS e WHERE e.id = ? AND e.id_question = q.id";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("i", $id);
			$stmt->bind_result($content, $likes, $date, $moderation);
			if (!$stmt->execute())
				logging("ERROR", "execute failed - reason:" . $stmt->error, "getQuestion", "dbfunctions.php");
			else {
				$stmt->fetch();

				include('drawQuestion.php');

			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "getQuestion", "dbfunctions.php");
		}

	}

	/*****************
		  Function : getQuestionAnimateur
		  Parameters : 
		    $cnx : DB connection
		    $id : evqust id
		  Output : HTML draw question
	*****************/

	function getQuestionAnimateur($cnx, $id) {
		$content = null;
		$likes = null;
		$date = null;
		$sql = "SELECT q.content AS content, e.likes AS likes, e.date AS date, e.moderation AS moderation FROM questions AS q, evqust AS e WHERE e.id = ? AND e.id_question = q.id";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("i", $id);
			$stmt->bind_result($content, $likes, $date, $moderation);
			if (!$stmt->execute())
				logging("ERROR", "execute failed - reason:" . $stmt->error, "getQuestionAnimateur", "dbfunctions.php");
			else {
				$stmt->fetch();

				include('drawQuestionAnimateur.php');

			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "getQuestionAnimateur", "dbfunctions.php");
		}

	}

	/*****************
		  Function : getQuestionModerateur
		  Parameters : 
		    $cnx : DB connection
		    $id : evqust id
		  Output : HTML draw question
	*****************/

	function getQuestionModerateur($cnx, $id) {
		$content = null;
		$likes = null;
		$date = null;
		$sql = "SELECT q.content AS content, e.likes AS likes, e.date AS date, e.moderation AS moderation FROM questions AS q, evqust AS e WHERE e.id = ? AND e.id_question = q.id";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("i", $id);
			$stmt->bind_result($content, $likes, $date, $moderation);
			if (!$stmt->execute())
				logging("ERROR", "execute failed - reason:" . $stmt->error, "getQuestionModerateur", "dbfunctions.php");
			else {
				$stmt->fetch();

				include('drawQuestionModerateur.php');

			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "getQuestionModerateur", "dbfunctions.php");
		}

	}

	/*****************
		  Function : addQuestion
		  Parameters : 
		    $cnx : DB connection
		    $user : user id
		    $event : event id
		    $question : question text
		  Output : 1 or 0 (error)
	*****************/

	function addQuestion($cnx, $user, $event, $question) {
		$sql = "CALL addQuestion(?, ?, ?)";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("iis", $user, $event, $question);
			if (!$stmt->execute()) {
				logging("ERROR", "execute failed - reason:" . $stmt->error, "addQuestion", "dbfunctions.php");
				echo 0;
			} else {

				echo 1;
			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "addQuestion", "dbfunctions.php");
			echo 0;
		}

	}

	/*****************
		  Function : addLike
		  Parameters : 
		    $cnx : DB connection
		    $user : user id
		    $event : event id
		    $question : question text
		  Output : 1 or 0 (error)
	*****************/

	function addLike($cnx, $user, $event, $evqust, $likes) {
		$sql = "CALL addLikes(?, ?, ?, ?)";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("iiii", $user, $event, $evqust, $likes);
			if (!$stmt->execute()) {
				logging("ERROR", "execute failed - reason:" . $stmt->error, "addLike", "dbfunctions.php");
				echo 0;
			} else {

				echo 1;
			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "addLike", "dbfunctions.php");
			echo 0;
		}

	}

	/*****************
		  Function : closeQuestion
		  Parameters : 
		    $cnx : DB connection
		    $user : user id
		    $event : evqust id
		  Output : 1 or 0 (error)
	*****************/

	function closeQuestion($cnx, $user, $evqust) {
		$sql = "CALL closeQuestion(?, ?)";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("ii", $evqust, $user);
			if (!$stmt->execute()) {
				logging("ERROR", "execute failed - reason:" . $stmt->error, "closeQuestion", "dbfunctions.php");
				echo 0;
			} else {

				echo 1;
			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "closeQuestion", "dbfunctions.php");
			echo 0;
		}

	}

	/*****************
		  Function : moderateQuestion
		  Parameters : 
		    $cnx : DB connection
		    $user : user id
		    $event : evqust id
		  Output : 1 or 0 (error)
	*****************/

	function moderateQuestion($cnx, $user, $evqust) {
		$sql = "CALL moderateQuestion(?, ?)";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("ii", $evqust, $user);
			if (!$stmt->execute()) {
				logging("ERROR", "execute failed - reason:" . $stmt->error, "moderateQuestion", "dbfunctions.php");
				echo 0;
			} else {

				echo 1;
			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "moderateQuestion", "dbfunctions.php");
			echo 0;
		}

	}

	/*****************
		  Function : getReview
		  Parameters : 
		    $cnx : DB connection
		    $last_date : previous date
		  Output : JSON output
	*****************/

	function getReview($cnx, $last_date) {
		$sql = "SELECT id_evqust AS id, type, infos, date AS last FROM review WHERE date >= ? ORDER BY last";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("s", $last_date);
			$stmt->bind_result($id, $type, $infos, $last);
			if (!$stmt->execute())
				logging("ERROR", "execute failed - reason:" . $stmt->error, "getReview", "dbfunctions.php");
			else {

				$first = true;
				while($stmt->fetch()) {
					if ($first) $first = false; else echo ", " . PHP_EOL;
					echo "{ \"id\" : " . $id . ", \"type\" : \"" . $type . "\", \"infos\" : " . $infos . ", \"last\" : \"" . $last . "\" }" . PHP_EOL;
				}

			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "getReview", "dbfunctions.php");
		}

	}

	/*****************
		  Function : disconnect
		  Parameters : 
		    $cnx : DB connection
		    $user : user id
		    $event : event id
		  Output : 1 or 0 (error)
	*****************/

	function disconnect($cnx, $user, $event) {
		$sql = "CALL disconnect(?, ?)";
		if ($stmt = $cnx->prepare($sql)) {
			$stmt->bind_param("ii", $user, $event);
			if (!$stmt->execute()) {
				logging("ERROR", "execute failed - reason:" . $stmt->error, "disconnect", "dbfunctions.php");
				echo 0;
			} else {

				if (array_key_exists('session', $_COOKIE)) {
					$_COOKIE['session'] = "";
				}

				echo 1;
			}
			$stmt->close();
		} else {
			logging("ERROR", "error stmt - reason:" . $cnx->error, "disconnect", "dbfunctions.php");
			echo 0;
		}

	}
?>