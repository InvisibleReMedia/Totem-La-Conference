<?php
	include('mongodb.php');
	include('connectodb.php');// connection method to db is not browsable
	include('getsession.php');
	include('dbfunctions.php');
	$last_date = null;
	if (array_key_exists('last_date', $_GET))
		$last_date = $_GET['last_date'];

	$cnx = connect_to_db('admin', false);
	echo "[" . PHP_EOL;
	if (getSession($cnx, $user, $event)  && $last_date) {
		getReview($cnx, $last_date);
	} else {
		logging("warning", "connection without session", "getSession", "review.php");
	}
	echo "]" . PHP_EOL;
?>