<?php
	include('mongodb.php');
	include('connectodb.php');// connection method to db is not browsable
	include('getsession.php');
	include('dbfunctions.php');
	$cnx = connect_to_db('admin', true);
	
	
?><!DOCTYPE html><html
	lang="fr"
	><head
		><meta charset="utf-8"><meta name="author" content="Business Forward Technology (business.forward.technology@gmail.com)"><meta name="description" content="Login - TOTEM La conférence"><meta name="keywords" content="IHACOM TOTEM La conférence"><meta name="generator" content="aloha - a programming language"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="preload" as="font" type="font/ttf" crossorigin="" href="fonts/Open-Sans/OpenSans-Regular.ttf"/><link rel="icon" href="favicon.ico"/><title
			>Page d'authentification - TOTEM La conférence</title
		><link rel="stylesheet" href="css/horizontal-styles.css"/><link rel="stylesheet" href="css/vertical-styles.css" media="all and (orientation: landscape)"/><link href="css/model2.css" rel="stylesheet"/><style
			>
				.errorArea {
					font-family:Open-Sans, Arial, Helvetica;
					font-size:1em;
				}
				.loginArea {
					margin-top:5px;
				}
				.eventArea {
					margin-top:5px;
				}
				.eventList {
					position:relative;
					padding:0;
					box-sizing:content-box;
					list-style:none;
					width:100%;
					vertical-align:middle;
				}
				.eventItem {
					display:inline-block;
					background-color:rgba(249,177,51,1.0);
					color:white;
					font-family:Open-Sans;
					font-size:small;
					border:1px solid black;
					border-radius:15px;
					box-shadow:1px 3px 3px 0px black;
					padding:2px;
					text-align:center;
					overflow:hidden;
					cursor:pointer;
					transition: background-color 1s;
				}
				.eventItem:active {
					background-color:rgba(249,177,51,0.7);
				}
				.selected {
					background-color:yellow;
				}
				dt {
					text-decoration:underline;
					font-family:Open-Sans, Arial, Helvetica;
					font-size:0.8em;
				}
				input[type=text] {
					border-radius:15px;
					background-color:yellow;
					color:white;
					width:100%;
				}
				input[type=text]:focus {
					outline-style:none;
					border:1px solid red;
				}
				input[type=button] {
					font-family:Open-Sans, Arial, Helvetica;
					font-size:1em;
					border-radius:15px;
					background-color:yellow;
					color:white;
				}
				input[type=button]:focus {
					outline-style:none;
					border:1px solid red;
				}</style
		></head
	><body
		><div
			class="vbox-a"
			><div
				class="vbox-element-b"
				><div
					class="hbox-c"
					><div
						class="hbox-element-d"
						>&nbsp;</div
					><div
						class="hbox-element-e"
						><div
							class="vbox-f"
							><div
								class="vbox-element-g"
								>&nbsp;</div
							><div
								class="vbox-element-h hideSB"
								><header
									style="display:inline-flex;height:30px;width:100%;display:inline-block;border-bottom:1px solid white;margin-bottom:20px"
									><div
										style="width:100%"
										><span
											class="title"
											>Login</span
										></div
									></header
								><div
									class="errorArea"
									style="display:inline-flex;height:30px;width:100%;margin:0 auto"
									><div
										style="width:100%"
										><span
											style="margin:0 auto;padding-left:20px;padding-right:20px;width:200px;border:1px solid white;border-radius:15px;background-color:rgba(249,177,51,1.0);color:red;font-family:Open-Sans, Arial, Helvetica;font-size:1em;font-weight:bold;display:block;text-align:center"
											id="msg"
											>Authentification</span
										></div
									></div
								><div
									class="loginArea"
									style="display:inline-flex;height:60px;width:100%"
									><div
										style="width:100%"
										><div
											class="flex-row"
											style="width:320px;height:100%;margin-left:auto;margin-right:auto;height:80px;vertical-align:middle"
											><div
												style="height:50%"
												><dl
													style="display:inline-flex;height:30px;width:100%"
													><div
														style="width:30%"
														><dt
															>Prénom</dt
														></div
													><div
														style="width:70%"
														><dt
															><input type="text" id="firstName" autocomplete="firstName" placeholder="Votre prénom"/></dt
														></div
													></dl
												></div
											><div
												style="height:50%"
												><dl
													style="display:inline-flex;height:30px;width:100%"
													><div
														style="width:30%"
														><dt
															>Nom</dt
														></div
													><div
														style="width:70%"
														><dt
															><input type="text" id="lastName" autocomplete="lastName" placeholder="Votre nom"/></dt
														></div
													></dl
												></div
											></div
										></div
									></div
								><input type="hidden" id="eventId"/><div
									style="height:20px"
									>&nbsp;</div
								><div
									class="flex-row eventArea"
									style="width:320px;height:100%;margin-left:auto;margin-right:auto;height:auto"
									><div
										style="height:100%"
										><ul
											class="eventList"
											><?php
											$sql = "SELECT id, title, date_start, date_end FROM events WHERE date_start > NOW()";
													if ($fetch = $cnx->query($sql)) {
															if (($count_rows = $fetch->num_rows) > 0) {
				
																	while($row = $fetch->fetch_assoc()) {
																			?><li
															class="eventItem"
															style="display:inline-flex;height:60px;width:100%;width:60px"
															data-id="<?php echo $row['id']?>"
															><div
																style="width:100%"
																><div
																	class="flex-row"
																	style="width:60px;height:100%;font-size:0.5em"
																	data-id="<?php echo $row['id']?>"
																	><div
																		style="height:34%"
																		><?php echo htmlspecialchars($row['title']);?></div
																	><div
																		style="height:34%"
																		><?php 
																					$d = strtotime($row['date_start']);
																					echo "du " . date("d/m", $d) . " à " . date("H:i", $d);?></div
																	><div
																		style="height:32%"
																		><?php 
																					$d = strtotime($row['date_end']);
																					echo "au " . date("d/m", $d) . " à " . date("H:i", $d);?></div
																	></div
																></div
															></li
														><?php

																	}
				
															} else {
				
															}
													} else {
															logging("ERROR", "error query - reason:" . $cnx->error, "", "login.php");
													}
													?></ul
										></div
									></div
								><div
									class="flex-row"
									style="width:320px;height:100%;height:30px;margin-left:auto;margin-right:auto;margin-top:5px"
									><div
										style="height:100%"
										><input style="float:right" disabled="true" type="button" id="submit" value="Valider"/></div
									></div
								></div
							></div
						></div
					><div
						class="hbox-element-i"
						>&nbsp;</div
					></div
				></div
			></div
		><script
			language="JavaScript"
			>
					function query() {
			        	var fName = document.getElementById("firstName")
			        	var lName = document.getElementById("lastName")
			        	var event = document.getElementById("eventId")
			        	var qs = {
			            	"firstName" : fName.value,
			            	"lastName" : lName.value,
			            	"id_event" : event.value
				        }
			        	var url = "verifyUser.php?" +
			          		Object.keys(qs)
			            		.map(x => encodeURIComponent(x) + '=' + encodeURIComponent(qs[x]))
			            		.join('&')
			        	fetch(url)
			          		.then(response => response.text())
			          		.then(text => {
			            		if (text) {
			              			let m = document.getElementById("msg")
									m.innerText = "Authentification"
			              			document.cookie = "session=" + text + "; expires=" + new Date(Date.now() + 1000*3600*24).toString()
			              			document.location = "menu.php"
			            		}
			            		else {
			              			let m = document.getElementById("msg")
									m.innerText = "Erreur d'authentification"
								}
			          		})
			          		.catch(error => console.error(error))
			      	}
					let b = document.getElementById('submit')
					b.addEventListener('click', query)
					var currentEvent = false
					let firstN = document.getElementById('firstName')
					let lastN = document.getElementById('lastName')
					firstN.addEventListener('change', function(e) {
						if (firstN.value && lastN.value && currentEvent) {
							b.disabled = false
						} else {
							b.disabled = true
						}
					})
					lastN.addEventListener('change', function(e) {
						if (firstN.value && lastN.value && currentEvent) {
							b.disabled = false
						} else {
							b.disabled = true
						}
					})
					let l = document.getElementsByClassName('eventItem')
					for(const x of l) {
						x.addEventListener('click', function(e) {
							if (currentEvent) {
								currentEvent.classList.toggle('selected')
							}
							let v = document.getElementById('eventId')
							v.value = x.dataset.id
							x.classList.toggle('selected')
							currentEvent = x
							if (firstN.value && lastN.value) {
								b.disabled = false
							} else {
								b.disabled = true
							}
						})
					}
					</script
		></body
	></html
><?php

?>