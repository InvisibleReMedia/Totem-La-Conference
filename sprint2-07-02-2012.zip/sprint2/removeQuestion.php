<?php
	include('mongodb.php');
	include('connectodb.php');// connection method to db is not browsable
	include('getsession.php');
	include('dbfunctions.php');
	$id = null;
	if (array_key_exists('id', $_GET))
		$id = $_GET['id'];

	$cnx = connect_to_db('admin', false);
	if (getSession($cnx, $user, $event)  && $id) {
		closeQuestion($cnx, $user, $id);
	} else {
		logging("warning", "connection without session", "getSession", "removeQuestion.php");
		echo 0;
	}

?>