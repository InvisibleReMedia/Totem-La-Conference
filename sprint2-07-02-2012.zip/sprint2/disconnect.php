<?php
	include('mongodb.php');
	include('connectodb.php');// connection method to db is not browsable
	include('getsession.php');
	include('dbfunctions.php');

	$cnx = connect_to_db('admin', false);
	if (getSession($cnx, $user, $event) ) {
		disconnect($cnx, $user, $event );
	} else {
		logging("warning", "connection without session", "getSession", "disconnect.php");
		echo 0;
	}

?>