
<?php
	include('mongodb.php');
	include('connectodb.php');// connection method to db is not browsable
	include('getsession.php');
	include('dbfunctions.php');
	$cnx = connect_to_db('admin', false);
	if (getSession($cnx, $user, $event)) {
		echo 1;
	} else {
		logging("warning", "connection without session", "getSession", "testSession.php");
		echo 0;
	}

?>