<div
	class="question"
	name="aQuestion"
	data-evqust="<?php echo $id?>"
	><input type="checkbox" name="moderated" data-evqust="<?php echo $id?>" value="<?php if ($moderation == 0) echo "false"; else echo "true" ?>"/><?php echo htmlspecialchars($content)?><img class="heart" tabindex="-1" draggable="false" data-evqust="<?php echo $id?>" src="images/heart.png" alt="Likez"/><span
		name="likes"
		class="counter"
		data-evqust="<?php echo $id?>"
		><?php echo $likes?></span
	><br/><img class="trash" tabIndex="-1" draggable="false" data-evqust="<?php echo $id?>" src="images/trash.png" alt="Supprimer"/></div
>