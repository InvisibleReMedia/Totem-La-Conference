-- --------------------------------------------------------
-- Hôte :                        127.0.0.1
-- Version du serveur:           8.0.21 - MySQL Community Server - GPL
-- SE du serveur:                Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Listage de la structure de la procédure moju. addLikes
DROP PROCEDURE IF EXISTS `addLikes`;
DELIMITER //
CREATE PROCEDURE `addLikes`(
	IN `id_user` MEDIUMINT,
	IN `id_event` MEDIUMINT,
	IN `id_evqust` MEDIUMINT,
	IN `newLikes` MEDIUMINT
)
    NO SQL
BEGIN
		DECLARE curDate DATETIME;
		DECLARE multiple_likes TINYINT(1);
		DECLARE permissions INT DEFAULT 0;
		DECLARE insert_review TINYINT(1);
		DECLARE insert_likes MEDIUMINT;
		DECLARE total_likes MEDIUMINT;

		SET @multiple_likes = 0;
		SELECT JSON_EXTRACT(e.infos, "$.multipleLikes")
		FROM events AS e
		WHERE e.id = id_event
		INTO @multiple_likes;

	   SELECT u.permissions
   	FROM users AS u
    	WHERE u.id = id_user
    	INTO @permissions;
		SET @insert_likes = newLikes;
		SET @insert_review = 0;
		SET @curDate = NOW();
		-- s'il existe déjà des likes pour cet utilisateur
		IF (SELECT EXISTS(SELECT l.likes
						  FROM likes AS l
						  WHERE l.id_evqust = id_evqust AND l.id_user = id_user)) THEN
			IF @multiple_likes = 1 OR (@permissions & 2) = 2 OR (@permissions & 8) = 8 THEN
				UPDATE likes AS l
				SET l.likes = l.likes + newLikes
				WHERE l.id_evqust = id_evqust AND l.id_user = id_user;
				SET @insert_review = 1;
			END IF;
		ELSE
			SET @insert_review = 1;
			IF @multiple_likes = 1 OR (@permissions & 2) = 2 OR (@permissions & 8) = 8 THEN
				INSERT INTO likes(id_evqust,id_user,likes)
				VALUES (id_evqust, id_user, newLikes);
			ELSE
				INSERT INTO likes(id_evqust, id_user, likes)
				VALUES (id_evqust, id_user, 1);
         	SET @insert_likes = 1;
			END IF;
		END IF;

		IF @insert_review = 1 THEN
            -- Mise à jour de la table REVIEW
			UPDATE evqust AS e
			SET e.likes = (SELECT SUM(likes) FROM likes AS l WHERE l.id_evqust = id_evqust)
			WHERE e.id = id_evqust;
			SELECT e.likes
			FROM evqust AS e
			WHERE e.id = id_evqust
			INTO @total_likes;
			-- Ajoute un enregistrement dans la table
			INSERT INTO review(date, id_evqust, id_user, type, description, infos)
			VALUES (@curDate, id_evqust, id_user, 'LIKES', 'Ajout de like', JSON_OBJECT('likes', @insert_likes, 'totalLikes', @total_likes));
		END IF;
END//
DELIMITER ;

-- Listage de la structure de la procédure moju. addQuestion
DROP PROCEDURE IF EXISTS `addQuestion`;
DELIMITER //
CREATE PROCEDURE `addQuestion`(
	IN `id_user` MEDIUMINT,
	IN `id_event` MEDIUMINT,
	IN `question` VARCHAR(256),
	IN `source` SMALLINT
)
BEGIN
DECLARE curEvent MEDIUMINT;
DECLARE curQuestion MEDIUMINT;
DECLARE curDate DATETIME;
DECLARE id_evqust MEDIUMINT;
DECLARE auto_moderate TINYINT(1);
DECLARE insert_review TINYINT(1);


-- si la question existe déjà
IF (SELECT EXISTS(SELECT e.id_event
  						FROM evqust AS e,
  							  questions AS q
  						WHERE e.id_question = q.id
  						AND q.content = question)) THEN
    SELECT id
    FROM questions
    WHERE content = question
    INTO @curQuestion;
  	UPDATE questions SET readOnly = true WHERE id = @curQuestion;
  	-- si cette question est déjà dans l'événement
  	IF (SELECT EXISTS(SELECT ev.id
						FROM evqust AS ev, questions AS q
						WHERE ev.id_question = q.id AND q.content = question AND ev.id_event = id_event
						AND ((ev.id_user = id_user AND (SELECT JSON_EXTRACT(e.infos, "$.duplicateQuestionType") = "perUser"
													FROM events AS e WHERE e.id = id_event)) OR 
							  (SELECT IFNULL(JSON_EXTRACT(e.infos, "$.duplicateQuestionType"),"perEvent") = "perEvent"
							  	FROM events AS e WHERE e.id = id_event)))) THEN
	  	SET @insert_review = 0;
	ELSE
		SET @insert_review = 1;
	END IF;
ELSE
	INSERT INTO questions(content,
			              readOnly)
	VALUES (question,
		    false);
	SET @curQuestion = LAST_INSERT_ID();
	SET @insert_review = 1;
END IF;

IF @insert_review = 1 THEN
	SET @curDate = NOW();
	SELECT JSON_EXTRACT(e.infos, "$.automaticModeration")
	FROM events AS e
	WHERE e.id = id_event
	INTO @auto_moderate;
	IF ISNULL(@auto_moderate) THEN
		SET @auto_moderate = 0;
	END IF;
	INSERT INTO evqust(id_question,
		           		 id_event,
		           		 id_user,
		           		 `date`,
		           		 `source`,
				   		 `likes`,
				   		 moderation,
		           		 suppressed)
	VALUES (@curQuestion,
		    id_event,
			 id_user,
	    	 @curDate,
	    	 `source`,
	    	 0,
	    	 @auto_moderate,
	    	 false);
	SET @id_evqust = LAST_INSERT_ID();
	-- Mise à jour de la table REVIEW
	-- Ajoute un enregistrement dans la table
	INSERT INTO review(`date`, id_evqust, id_user, type, description, infos)
	VALUES (@curDate, @id_evqust, id_user, 'QUESTION', 'Ajout d\'une question', JSON_OBJECT('question', @curQuestion, 'source', `source`));
END IF;
END//
DELIMITER ;

-- Listage de la structure de la procédure moju. closeQuestion
DROP PROCEDURE IF EXISTS `closeQuestion`;
DELIMITER //
CREATE PROCEDURE `closeQuestion`(
	IN `id_evqust` MEDIUMINT,
	IN `id_user` MEDIUMINT
)
    NO SQL
BEGIN
	DECLARE suppressed TINYINT(1) DEFAULT 0;
    DECLARE permissions INT DEFAULT 0;
    DECLARE id_question MEDIUMINT;
    SELECT e.suppressed, e.id_question
    FROM evqust AS e
    WHERE e.id = id_evqust
    INTO @suppressed,
    	 @id_question;
    SELECT u.permissions
    FROM users AS u
    WHERE u.id = id_user
    INTO @permissions;
    IF @suppressed = 0 AND (@permissions & 2) = 2 THEN
		UPDATE evqust
		SET suppressed = 1
		WHERE id = id_evqust;
        INSERT INTO review(id_evqust, id_user, `date`, type, description, infos) VALUES (id_evqust, id_user, NOW(), 'SUPPRESSED', 'Suppression d\'une question', JSON_OBJECT('question', @id_question));
    END IF;
END//
DELIMITER ;

-- Listage de la structure de la fonction moju. createUser
DROP FUNCTION IF EXISTS `createUser`;
DELIMITER //
CREATE FUNCTION `createUser`(
	`id_event` MEDIUMINT
) RETURNS varchar(128) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
BEGIN
	DECLARE cur_date DATETIME;
	DECLARE res TINYINT(1) DEFAULT 0;
	DECLARE new_s VARCHAR(256);
	DECLARE id_user MEDIUMINT;

   INSERT INTO users(greetings, firstName, lastName) VALUES("", "", "");
   SET @id_user = LAST_INSERT_ID();
   SET @cur_date = NOW();
   SET @new_s = MD5(CONCAT("Bienvenue sur le site - user ", @id_user, ", il est ", @cur_date));
  	INSERT INTO sessions(`session`, date_start, id_user, id_event) VALUES(@new_s, @cur_date, @id_user, id_event);
   RETURN @new_s;
END//
DELIMITER ;

-- Listage de la structure de la procédure moju. disconnect
DROP PROCEDURE IF EXISTS `disconnect`;
DELIMITER //
CREATE PROCEDURE `disconnect`(
	IN `id_user` MEDIUMINT,
	IN `id_event` MEDIUMINT
)
BEGIN
	UPDATE sessions AS s SET date_end = NOW() WHERE s.id_user = id_user AND s.id_event = id_event;
END//
DELIMITER ;

-- Listage de la structure de la table moju. events
DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `title` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `address` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `infos` json NOT NULL,
  `suppressed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`title`,`date_start`,`date_end`,`address`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.events : ~3 rows (environ)
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` (`id`, `title`, `date_start`, `date_end`, `address`, `infos`, `suppressed`) VALUES
	(1, 'test', '2021-01-01 00:00:00', '2021-01-31 00:00:00', 'ici', '{}', 0),
	(2, 'test 2', '2021-03-01 00:00:00', '2021-05-28 00:00:00', 'ici', '{"multipleLikes": 1, "automaticModeration": 1}', 1),
	(3, 'test 3', '2021-04-10 10:00:00', '2021-04-10 18:00:00', 'En normandie', '{"duplicateQuestionType": "perUser"}', 0);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;

-- Listage de la structure de la table moju. evqust
DROP TABLE IF EXISTS `evqust`;
CREATE TABLE IF NOT EXISTS `evqust` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `id_event` mediumint NOT NULL,
  `id_question` mediumint NOT NULL,
  `id_user` mediumint NOT NULL,
  `date` datetime NOT NULL,
  `source` smallint NOT NULL DEFAULT '0',
  `likes` int NOT NULL DEFAULT '0',
  `selected` tinyint NOT NULL DEFAULT '0',
  `moderation` tinyint(1) NOT NULL DEFAULT '0',
  `suppressed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_evqst` (`id_event`,`id_question`,`id_user`,`date`) USING BTREE,
  KEY `id_event` (`id_event`),
  KEY `id_question` (`id_question`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `evqust_ibfk_1` FOREIGN KEY (`id_event`) REFERENCES `events` (`id`),
  CONSTRAINT `evqust_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.evqust : ~67 rows (environ)
/*!40000 ALTER TABLE `evqust` DISABLE KEYS */;
INSERT INTO `evqust` (`id`, `id_event`, `id_question`, `id_user`, `date`, `source`, `likes`, `selected`, `moderation`, `suppressed`) VALUES
	(192, 1, 11, 1, '2021-02-18 07:34:05', 0, 0, 0, 0, 0),
	(193, 3, 11, 2, '2021-02-18 07:53:35', 0, 0, 0, 1, 0),
	(194, 3, 11, 1, '2021-02-18 07:55:28', 0, 0, 0, 0, 1),
	(196, 3, 11, 5, '2021-02-18 07:56:25', 0, 4, 0, 1, 0),
	(197, 1, 13, 5, '2021-02-18 07:59:06', 0, 0, 0, 0, 0),
	(198, 3, 13, 5, '2021-02-18 07:59:19', 0, 0, 0, 1, 0),
	(199, 3, 13, 1, '2021-02-18 07:59:35', 0, 0, 0, 1, 0),
	(200, 3, 14, 25, '2021-02-23 05:14:08', 0, 1, 0, 1, 0),
	(201, 3, 15, 28, '2021-02-23 06:24:16', 0, 1, 0, 1, 0),
	(202, 3, 14, 2, '2021-02-25 07:41:52', 0, 0, 0, 0, 1),
	(203, 3, 16, 2, '2021-02-25 07:43:37', 0, 9, 0, 1, 0),
	(204, 3, 13, 2, '2021-02-25 07:46:50', 0, 0, 0, 1, 1),
	(205, 3, 17, 2, '2021-02-25 07:49:47', 0, 2, 0, 1, 0),
	(206, 3, 18, 2, '2021-02-25 08:02:50', 0, 0, 0, 1, 1),
	(207, 3, 19, 2, '2021-02-25 08:50:34', 0, 6, 0, 1, 0),
	(208, 3, 20, 2, '2021-02-25 08:52:47', 0, 0, 0, 1, 0),
	(209, 3, 21, 2, '2021-02-25 08:53:00', 0, 0, 0, 1, 0),
	(210, 3, 22, 2, '2021-02-25 08:53:22', 0, 7, 0, 1, 0),
	(211, 3, 23, 2, '2021-02-25 08:54:05', 0, 4, 1, 1, 0),
	(212, 3, 24, 2, '2021-02-25 08:54:20', 0, 5, 0, 1, 0),
	(213, 3, 25, 2, '2021-02-25 08:54:34', 0, 4, 0, 1, 0),
	(214, 3, 26, 2, '2021-02-25 08:54:49', 0, 10, 0, 1, 0),
	(215, 3, 27, 2, '2021-02-25 08:57:03', 0, 0, 0, 1, 0),
	(216, 3, 28, 2, '2021-02-25 08:57:22', 0, 0, 0, 1, 0),
	(217, 3, 29, 2, '2021-02-25 08:57:34', 0, 0, 0, 1, 0),
	(218, 3, 30, 2, '2021-02-25 08:57:41', 0, 1, 0, 1, 0),
	(219, 3, 31, 2, '2021-02-25 08:57:49', 0, 0, 0, 1, 0),
	(220, 3, 32, 2, '2021-02-25 08:58:04', 0, 0, 0, 1, 0),
	(221, 3, 33, 2, '2021-02-25 08:58:21', 0, 1, 0, 1, 0),
	(222, 3, 34, 2, '2021-02-25 08:58:35', 0, 3, 1, 1, 1),
	(223, 3, 35, 2, '2021-02-25 08:59:29', 0, 0, 0, 1, 0),
	(224, 3, 36, 2, '2021-02-25 08:59:51', 0, 2, 1, 1, 0),
	(225, 3, 37, 2, '2021-02-25 09:00:01', 0, 4, 0, 1, 0),
	(226, 3, 38, 2, '2021-02-25 09:00:13', 0, 0, 0, 1, 0),
	(227, 3, 39, 2, '2021-02-25 09:00:23', 0, 0, 0, 1, 0),
	(228, 3, 40, 2, '2021-02-25 09:00:30', 0, 1, 0, 1, 0),
	(229, 3, 41, 2, '2021-02-25 09:00:33', 0, 6, 1, 1, 1),
	(230, 3, 42, 2, '2021-02-25 09:00:38', 0, 6, 0, 1, 0),
	(231, 3, 43, 2, '2021-02-25 09:00:45', 0, 1, 0, 1, 0),
	(232, 3, 44, 2, '2021-02-25 09:00:49', 0, 0, 0, 1, 0),
	(233, 3, 45, 2, '2021-02-25 09:00:56', 0, 4, 0, 1, 0),
	(234, 3, 46, 2, '2021-02-25 09:01:07', 0, 0, 0, 1, 0),
	(235, 3, 47, 2, '2021-02-25 09:01:10', 0, 1, 0, 1, 0),
	(236, 3, 48, 2, '2021-02-25 09:01:13', 0, 1, 0, 1, 0),
	(237, 3, 49, 2, '2021-02-25 09:01:16', 0, 1, 1, 1, 1),
	(238, 3, 50, 2, '2021-02-25 09:01:19', 0, 0, 0, 1, 0),
	(239, 3, 51, 2, '2021-02-25 09:01:22', 0, 0, 0, 1, 0),
	(240, 3, 52, 2, '2021-02-25 09:01:26', 0, 1, 0, 1, 0),
	(241, 3, 53, 2, '2021-02-25 09:01:34', 0, 0, 0, 1, 0),
	(242, 3, 54, 2, '2021-02-25 09:01:38', 0, 1, 0, 1, 0),
	(243, 3, 55, 2, '2021-02-25 09:01:41', 0, 1, 0, 1, 0),
	(244, 3, 56, 2, '2021-02-25 09:01:45', 0, 0, 0, 1, 0),
	(245, 3, 57, 2, '2021-02-25 09:01:49', 0, 0, 0, 1, 0),
	(246, 3, 58, 2, '2021-02-25 09:02:00', 0, 0, 0, 1, 0),
	(247, 3, 59, 2, '2021-02-25 09:02:13', 0, 0, 0, 1, 0),
	(248, 3, 60, 2, '2021-02-25 09:02:16', 0, 0, 0, 1, 0),
	(249, 3, 61, 2, '2021-02-25 09:02:19', 0, 0, 0, 1, 0),
	(250, 3, 62, 2, '2021-02-25 09:02:22', 0, 0, 0, 1, 0),
	(251, 3, 63, 2, '2021-02-25 09:23:43', 0, 8, 0, 1, 0),
	(252, 3, 64, 37, '2021-03-01 04:50:16', 0, 1, 0, 1, 0),
	(253, 3, 65, 2, '2021-03-01 04:54:53', 0, 0, 0, 0, 1),
	(254, 3, 66, 2, '2021-03-01 08:04:59', 0, 0, 0, 1, 0),
	(255, 3, 68, 2, '2021-03-01 08:15:53', 0, 0, 0, 1, 0),
	(256, 3, 69, 42, '2021-03-01 19:46:54', 0, 5, 0, 1, 0),
	(257, 3, 70, 43, '2021-03-02 03:57:25', 0, 4, 0, 1, 0),
	(258, 3, 71, 43, '2021-03-02 04:42:12', 0, 1, 0, 1, 0),
	(259, 3, 72, 44, '2021-03-03 09:19:13', 0, 12, 1, 1, 0),
	(260, 3, 73, 9, '2021-03-03 09:32:09', 1, 16, 1, 1, 0),
	(261, 3, 74, 9, '2021-03-03 09:52:51', 1, 28, 0, 1, 0),
	(262, 3, 75, 9, '2021-03-03 10:07:01', 1, 45, 0, 1, 0);
/*!40000 ALTER TABLE `evqust` ENABLE KEYS */;

-- Listage de la structure de la table moju. likes
DROP TABLE IF EXISTS `likes`;
CREATE TABLE IF NOT EXISTS `likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_evqust` mediumint NOT NULL,
  `id_user` mediumint NOT NULL,
  `likes` int NOT NULL DEFAULT '0',
  `suppressed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_evqust` (`id_evqust`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.likes : ~35 rows (environ)
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` (`id`, `id_evqust`, `id_user`, `likes`, `suppressed`) VALUES
	(1, 201, 35, 1, 0),
	(2, 200, 2, 1, 0),
	(3, 207, 2, 6, 0),
	(4, 205, 2, 2, 0),
	(5, 203, 2, 9, 0),
	(6, 210, 2, 7, 0),
	(7, 214, 2, 9, 0),
	(8, 213, 2, 4, 0),
	(9, 229, 2, 6, 0),
	(10, 221, 2, 1, 0),
	(11, 224, 2, 2, 0),
	(12, 236, 2, 1, 0),
	(13, 240, 2, 1, 0),
	(14, 235, 2, 1, 0),
	(15, 231, 2, 1, 0),
	(16, 212, 2, 5, 0),
	(17, 230, 2, 6, 0),
	(18, 225, 2, 4, 0),
	(19, 211, 2, 4, 0),
	(20, 222, 2, 3, 0),
	(21, 251, 2, 8, 0),
	(22, 218, 37, 1, 0),
	(23, 252, 38, 1, 0),
	(24, 242, 2, 1, 0),
	(25, 233, 2, 4, 0),
	(26, 196, 2, 4, 0),
	(27, 237, 2, 1, 0),
	(28, 228, 2, 1, 0),
	(29, 256, 2, 4, 0),
	(30, 256, 2, 1, 0),
	(31, 257, 8, 3, 0),
	(32, 243, 43, 1, 0),
	(33, 257, 43, 1, 0),
	(34, 258, 43, 1, 0),
	(35, 214, 44, 1, 0),
	(36, 259, 44, 1, 0),
	(37, 259, 2, 11, 0),
	(38, 260, 44, 1, 0),
	(39, 260, 2, 15, 0),
	(40, 261, 9, 28, 0),
	(41, 262, 9, 45, 0);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;

-- Listage de la structure de la table moju. logs
DROP TABLE IF EXISTS `logs`;
CREATE TABLE IF NOT EXISTS `logs` (
  `date` datetime NOT NULL,
  `severity` varchar(50) NOT NULL DEFAULT '',
  `desc` varchar(512) NOT NULL DEFAULT '',
  `trace` varchar(512) NOT NULL DEFAULT '',
  `origin` varchar(512) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Listage des données de la table moju.logs : 56 rows
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`date`, `severity`, `desc`, `trace`, `origin`) VALUES
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'review.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session or empty parameters', 'getSession', 'getQuestion.php'),
	('0000-00-00 00:00:00', 'warning', 'connection without session', 'getSession', 'testSession.php');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;

-- Listage de la structure de la procédure moju. moderateQuestion
DROP PROCEDURE IF EXISTS `moderateQuestion`;
DELIMITER //
CREATE PROCEDURE `moderateQuestion`(
	IN `id_evqust` MEDIUMINT,
	IN `id_user` MEDIUMINT
)
BEGIN
	DECLARE moderated TINYINT(1) DEFAULT 0;
    DECLARE permissions INT DEFAULT 0;
    DECLARE id_question MEDIUMINT;
    SELECT e.moderation, e.id_question
    FROM evqust AS e
    WHERE e.id = id_evqust
    INTO @moderated,
    	 @id_question;
    SELECT u.permissions
    FROM users AS u
    WHERE u.id = id_user
    INTO @permissions;
    IF (@permissions & 8) = 8 THEN
      IF @moderated = 1 THEN
			UPDATE evqust
			SET moderation = 0
			WHERE id = id_evqust;
         INSERT INTO review(id_evqust, id_user, `date`, type, description, infos) VALUES (id_evqust, id_user, NOW(), 'MODERATED', 'Modération d\'une question', JSON_OBJECT('question', @id_question, 'moderated', 0));
		ELSE
			UPDATE evqust
			SET moderation = 1
			WHERE id = id_evqust;
         INSERT INTO review(id_evqust, id_user, `date`, type, description, infos) VALUES (id_evqust, id_user, NOW(), 'MODERATED', 'Modération d\'une question', JSON_OBJECT('question', @id_question, 'moderated', 1));
		END IF;
    END IF;
END//
DELIMITER ;

-- Listage de la structure de la table moju. questions
DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `content` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `readOnly` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `content` (`content`),
  FULLTEXT KEY `search` (`content`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.questions : ~56 rows (environ)
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` (`id`, `content`, `readOnly`) VALUES
	(11, 'bonjour', 1),
	(13, 'coucou', 1),
	(14, 'test', 1),
	(15, 'lttzrez', 0),
	(16, 'ok', 1),
	(17, 'hello', 0),
	(18, 'salut !', 0),
	(19, 'poser une question', 0),
	(20, 'encore une question', 0),
	(21, 'j\'aime bien poser des questions', 0),
	(22, 'qu\'est ce que cela donne si mon texte est très long.............................................................................................................', 0),
	(23, 'je pose d\'autres questions\r\n', 0),
	(24, 'et si mon texte est lng', 0),
	(25, 'ajouter une nouvelle question', 0),
	(26, 'j\'aime bien la question de tout à l\'heure', 0),
	(27, 'd\'autres questions', 0),
	(28, 'nouvelle question', 0),
	(29, 'encore deux', 0),
	(30, 'suivante', 0),
	(31, 'taille', 0),
	(32, 'et encore', 0),
	(33, 'beaucoup de questions', 0),
	(34, 'en ligne', 0),
	(35, 'encore', 1),
	(36, 'je ne peux pas ajouter la même question', 0),
	(37, 'oui', 0),
	(38, 'oui oui', 0),
	(39, 'contrigbuter', 0),
	(40, 'rerze', 0),
	(41, 'cvvxc', 0),
	(42, 'rerez', 1),
	(43, 'xcvxcvxcvc', 0),
	(44, 'zzeaez', 0),
	(45, 'bvbcv', 0),
	(46, 'zerzerze', 0),
	(47, 'vxvc', 0),
	(48, 'zeza', 0),
	(49, 'hgfhf', 0),
	(50, 'lkjlj', 0),
	(51, ' ngnfh', 0),
	(52, 'uyoiuui', 0),
	(53, 'xwcscw', 0),
	(54, 'erzerz', 0),
	(55, 'vcbcvbcv', 0),
	(56, ',nb;,b', 0),
	(57, 'cdqsdqs', 0),
	(58, '<div></div>', 0),
	(59, 'rezrze', 0),
	(60, ' bcvb', 0),
	(61, 'hghgfhfg', 0),
	(62, '  bcvbv', 0),
	(63, 'jkjildfs sdfkjklsdk jkzelkl ejkljklzejkdjkjfksdlklf jzklrklez jkrezkjklekl zejklj d sdkl jsdkjkzdfklrzezioz jzzjzefjklfsdkrizeojiofjfizejkl  jkljdfks', 0),
	(64, 'jkjleizor ejkl', 0),
	(65, 'uyiyiuyui', 0),
	(66, '(\'terergre', 0),
	(68, 'coucou !!!!', 0),
	(69, 'yuihjk,nb  nbhhj :)', 0),
	(70, 'oioiiojin jhjkhk', 0),
	(71, 'yihuihuhjkj', 0),
	(72, 'new question !', 0),
	(73, 'je suis un client', 1),
	(74, 'test du client', 0),
	(75, 'nouveau client ! ', 0);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;

-- Listage de la structure de la table moju. review
DROP TABLE IF EXISTS `review`;
CREATE TABLE IF NOT EXISTS `review` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `id_user` mediumint NOT NULL,
  `id_evqust` mediumint NOT NULL,
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `infos` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_evqust` (`id_evqust`),
  KEY `ref` (`id_user`,`id_evqust`,`type`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`),
  CONSTRAINT `review_ibfk_2` FOREIGN KEY (`id_evqust`) REFERENCES `evqust` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.review : ~238 rows (environ)
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` (`id`, `date`, `id_user`, `id_evqust`, `type`, `description`, `infos`) VALUES
	(1, '2021-02-18 07:34:05', 1, 192, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 11}'),
	(2, '2021-02-18 07:53:35', 2, 193, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 11}'),
	(3, '2021-02-18 07:55:28', 1, 194, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 11}'),
	(4, '2021-02-18 07:56:25', 5, 196, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 11}'),
	(5, '2021-02-18 07:59:06', 5, 197, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 13}'),
	(6, '2021-02-18 07:59:19', 5, 198, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 13}'),
	(7, '2021-02-18 07:59:35', 1, 199, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 13}'),
	(8, '2021-02-23 05:14:08', 25, 200, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 14}'),
	(9, '2021-02-23 06:24:16', 28, 201, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 15}'),
	(10, '2021-02-25 06:30:07', 2, 194, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 11}'),
	(11, '2021-02-25 06:30:14', 2, 193, 'MODERATED', 'Modération d\'une question', '{"question": 11, "moderated": 1}'),
	(12, '2021-02-25 06:30:14', 2, 196, 'MODERATED', 'Modération d\'une question', '{"question": 11, "moderated": 1}'),
	(13, '2021-02-25 06:30:15', 2, 200, 'MODERATED', 'Modération d\'une question', '{"question": 14, "moderated": 1}'),
	(14, '2021-02-25 06:30:15', 2, 201, 'MODERATED', 'Modération d\'une question', '{"question": 15, "moderated": 1}'),
	(15, '2021-02-25 06:30:15', 2, 199, 'MODERATED', 'Modération d\'une question', '{"question": 13, "moderated": 1}'),
	(16, '2021-02-25 06:30:15', 2, 198, 'MODERATED', 'Modération d\'une question', '{"question": 13, "moderated": 1}'),
	(17, '2021-02-25 06:32:20', 35, 201, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(18, '2021-02-25 07:41:01', 2, 200, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(19, '2021-02-25 07:41:52', 2, 202, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 14}'),
	(20, '2021-02-25 07:43:07', 2, 202, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 14}'),
	(21, '2021-02-25 07:43:37', 2, 203, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 16}'),
	(22, '2021-02-25 07:46:24', 2, 203, 'MODERATED', 'Modération d\'une question', '{"question": 16, "moderated": 1}'),
	(23, '2021-02-25 07:46:50', 2, 204, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 13}'),
	(24, '2021-02-25 07:47:02', 2, 204, 'MODERATED', 'Modération d\'une question', '{"question": 13, "moderated": 1}'),
	(25, '2021-02-25 07:49:47', 2, 205, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 17}'),
	(26, '2021-02-25 08:02:50', 2, 206, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 18}'),
	(27, '2021-02-25 08:02:58', 2, 206, 'MODERATED', 'Modération d\'une question', '{"question": 18, "moderated": 1}'),
	(28, '2021-02-25 08:02:58', 2, 205, 'MODERATED', 'Modération d\'une question', '{"question": 17, "moderated": 1}'),
	(29, '2021-02-25 08:50:07', 2, 204, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 13}'),
	(30, '2021-02-25 08:50:17', 2, 206, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 18}'),
	(31, '2021-02-25 08:50:34', 2, 207, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 19}'),
	(32, '2021-02-25 08:50:53', 2, 207, 'MODERATED', 'Modération d\'une question', '{"question": 19, "moderated": 1}'),
	(33, '2021-02-25 08:51:03', 2, 207, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(34, '2021-02-25 08:51:06', 2, 207, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 2}'),
	(35, '2021-02-25 08:51:22', 2, 205, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(36, '2021-02-25 08:51:40', 2, 205, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 2}'),
	(37, '2021-02-25 08:51:53', 2, 203, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(38, '2021-02-25 08:51:56', 2, 203, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 5}'),
	(39, '2021-02-25 08:52:08', 2, 203, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 6}'),
	(40, '2021-02-25 08:52:47', 2, 208, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 20}'),
	(41, '2021-02-25 08:53:00', 2, 209, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 21}'),
	(42, '2021-02-25 08:53:22', 2, 210, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 22}'),
	(43, '2021-02-25 08:53:34', 2, 210, 'MODERATED', 'Modération d\'une question', '{"question": 22, "moderated": 1}'),
	(44, '2021-02-25 08:53:42', 2, 210, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 3}'),
	(45, '2021-02-25 08:54:05', 2, 211, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 23}'),
	(46, '2021-02-25 08:54:10', 2, 208, 'MODERATED', 'Modération d\'une question', '{"question": 20, "moderated": 1}'),
	(47, '2021-02-25 08:54:10', 2, 211, 'MODERATED', 'Modération d\'une question', '{"question": 23, "moderated": 1}'),
	(48, '2021-02-25 08:54:10', 2, 209, 'MODERATED', 'Modération d\'une question', '{"question": 21, "moderated": 1}'),
	(49, '2021-02-25 08:54:20', 2, 212, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 24}'),
	(50, '2021-02-25 08:54:23', 2, 212, 'MODERATED', 'Modération d\'une question', '{"question": 24, "moderated": 1}'),
	(51, '2021-02-25 08:54:34', 2, 213, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 25}'),
	(52, '2021-02-25 08:54:35', 2, 213, 'MODERATED', 'Modération d\'une question', '{"question": 25, "moderated": 1}'),
	(53, '2021-02-25 08:54:49', 2, 214, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 26}'),
	(54, '2021-02-25 08:54:53', 2, 214, 'MODERATED', 'Modération d\'une question', '{"question": 26, "moderated": 1}'),
	(55, '2021-02-25 08:55:11', 2, 214, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(56, '2021-02-25 08:55:24', 2, 214, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 2}'),
	(57, '2021-02-25 08:55:34', 2, 214, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 3}'),
	(58, '2021-02-25 08:55:37', 2, 214, 'LIKES', 'Ajout de like', '{"likes": 5, "totalLikes": 8}'),
	(59, '2021-02-25 08:55:48', 2, 214, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 9}'),
	(60, '2021-02-25 08:55:54', 2, 203, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 8}'),
	(61, '2021-02-25 08:56:04', 2, 203, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 9}'),
	(62, '2021-02-25 08:56:06', 2, 210, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 7}'),
	(63, '2021-02-25 08:56:31', 2, 207, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 6}'),
	(64, '2021-02-25 08:56:37', 2, 213, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 4}'),
	(65, '2021-02-25 08:57:03', 2, 215, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 27}'),
	(66, '2021-02-25 08:57:05', 2, 215, 'MODERATED', 'Modération d\'une question', '{"question": 27, "moderated": 1}'),
	(67, '2021-02-25 08:57:22', 2, 216, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 28}'),
	(68, '2021-02-25 08:57:26', 2, 216, 'MODERATED', 'Modération d\'une question', '{"question": 28, "moderated": 1}'),
	(69, '2021-02-25 08:57:34', 2, 217, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 29}'),
	(70, '2021-02-25 08:57:36', 2, 217, 'MODERATED', 'Modération d\'une question', '{"question": 29, "moderated": 1}'),
	(71, '2021-02-25 08:57:41', 2, 218, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 30}'),
	(72, '2021-02-25 08:57:43', 2, 218, 'MODERATED', 'Modération d\'une question', '{"question": 30, "moderated": 1}'),
	(73, '2021-02-25 08:57:49', 2, 219, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 31}'),
	(74, '2021-02-25 08:57:53', 2, 219, 'MODERATED', 'Modération d\'une question', '{"question": 31, "moderated": 1}'),
	(75, '2021-02-25 08:58:04', 2, 220, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 32}'),
	(76, '2021-02-25 08:58:11', 2, 220, 'MODERATED', 'Modération d\'une question', '{"question": 32, "moderated": 1}'),
	(77, '2021-02-25 08:58:21', 2, 221, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 33}'),
	(78, '2021-02-25 08:58:23', 2, 221, 'MODERATED', 'Modération d\'une question', '{"question": 33, "moderated": 1}'),
	(79, '2021-02-25 08:58:35', 2, 222, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 34}'),
	(80, '2021-02-25 08:58:38', 2, 222, 'MODERATED', 'Modération d\'une question', '{"question": 34, "moderated": 1}'),
	(81, '2021-02-25 08:59:29', 2, 223, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 35}'),
	(82, '2021-02-25 08:59:31', 2, 223, 'MODERATED', 'Modération d\'une question', '{"question": 35, "moderated": 1}'),
	(83, '2021-02-25 08:59:51', 2, 224, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 36}'),
	(84, '2021-02-25 08:59:54', 2, 224, 'MODERATED', 'Modération d\'une question', '{"question": 36, "moderated": 1}'),
	(85, '2021-02-25 09:00:01', 2, 225, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 37}'),
	(86, '2021-02-25 09:00:04', 2, 225, 'MODERATED', 'Modération d\'une question', '{"question": 37, "moderated": 1}'),
	(87, '2021-02-25 09:00:13', 2, 226, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 38}'),
	(88, '2021-02-25 09:00:16', 2, 226, 'MODERATED', 'Modération d\'une question', '{"question": 38, "moderated": 1}'),
	(89, '2021-02-25 09:00:23', 2, 227, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 39}'),
	(90, '2021-02-25 09:00:27', 2, 227, 'MODERATED', 'Modération d\'une question', '{"question": 39, "moderated": 1}'),
	(91, '2021-02-25 09:00:30', 2, 228, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 40}'),
	(92, '2021-02-25 09:00:33', 2, 229, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 41}'),
	(93, '2021-02-25 09:00:38', 2, 230, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 42}'),
	(94, '2021-02-25 09:00:45', 2, 231, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 43}'),
	(95, '2021-02-25 09:00:49', 2, 232, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 44}'),
	(96, '2021-02-25 09:00:56', 2, 233, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 45}'),
	(97, '2021-02-25 09:00:57', 2, 229, 'MODERATED', 'Modération d\'une question', '{"question": 41, "moderated": 1}'),
	(98, '2021-02-25 09:00:57', 2, 228, 'MODERATED', 'Modération d\'une question', '{"question": 40, "moderated": 1}'),
	(99, '2021-02-25 09:00:57', 2, 231, 'MODERATED', 'Modération d\'une question', '{"question": 43, "moderated": 1}'),
	(100, '2021-02-25 09:00:57', 2, 232, 'MODERATED', 'Modération d\'une question', '{"question": 44, "moderated": 1}'),
	(101, '2021-02-25 09:00:57', 2, 230, 'MODERATED', 'Modération d\'une question', '{"question": 42, "moderated": 1}'),
	(102, '2021-02-25 09:00:59', 2, 233, 'MODERATED', 'Modération d\'une question', '{"question": 45, "moderated": 1}'),
	(103, '2021-02-25 09:01:07', 2, 234, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 46}'),
	(104, '2021-02-25 09:01:10', 2, 235, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 47}'),
	(105, '2021-02-25 09:01:13', 2, 236, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 48}'),
	(106, '2021-02-25 09:01:16', 2, 237, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 49}'),
	(107, '2021-02-25 09:01:19', 2, 238, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 50}'),
	(108, '2021-02-25 09:01:22', 2, 239, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 51}'),
	(109, '2021-02-25 09:01:26', 2, 240, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 52}'),
	(110, '2021-02-25 09:01:28', 2, 234, 'MODERATED', 'Modération d\'une question', '{"question": 46, "moderated": 1}'),
	(111, '2021-02-25 09:01:28', 2, 235, 'MODERATED', 'Modération d\'une question', '{"question": 47, "moderated": 1}'),
	(112, '2021-02-25 09:01:28', 2, 239, 'MODERATED', 'Modération d\'une question', '{"question": 51, "moderated": 1}'),
	(113, '2021-02-25 09:01:28', 2, 240, 'MODERATED', 'Modération d\'une question', '{"question": 52, "moderated": 1}'),
	(114, '2021-02-25 09:01:28', 2, 236, 'MODERATED', 'Modération d\'une question', '{"question": 48, "moderated": 1}'),
	(115, '2021-02-25 09:01:28', 2, 238, 'MODERATED', 'Modération d\'une question', '{"question": 50, "moderated": 1}'),
	(116, '2021-02-25 09:01:28', 2, 237, 'MODERATED', 'Modération d\'une question', '{"question": 49, "moderated": 1}'),
	(117, '2021-02-25 09:01:34', 2, 241, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 53}'),
	(118, '2021-02-25 09:01:38', 2, 242, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 54}'),
	(119, '2021-02-25 09:01:41', 2, 243, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 55}'),
	(120, '2021-02-25 09:01:45', 2, 244, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 56}'),
	(121, '2021-02-25 09:01:49', 2, 245, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 57}'),
	(122, '2021-02-25 09:02:00', 2, 246, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 58}'),
	(123, '2021-02-25 09:02:03', 2, 241, 'MODERATED', 'Modération d\'une question', '{"question": 53, "moderated": 1}'),
	(124, '2021-02-25 09:02:03', 2, 244, 'MODERATED', 'Modération d\'une question', '{"question": 56, "moderated": 1}'),
	(125, '2021-02-25 09:02:03', 2, 242, 'MODERATED', 'Modération d\'une question', '{"question": 54, "moderated": 1}'),
	(126, '2021-02-25 09:02:03', 2, 243, 'MODERATED', 'Modération d\'une question', '{"question": 55, "moderated": 1}'),
	(127, '2021-02-25 09:02:03', 2, 246, 'MODERATED', 'Modération d\'une question', '{"question": 58, "moderated": 1}'),
	(128, '2021-02-25 09:02:03', 2, 245, 'MODERATED', 'Modération d\'une question', '{"question": 57, "moderated": 1}'),
	(129, '2021-02-25 09:02:13', 2, 247, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 59}'),
	(130, '2021-02-25 09:02:16', 2, 248, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 60}'),
	(131, '2021-02-25 09:02:19', 2, 249, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 61}'),
	(132, '2021-02-25 09:02:22', 2, 250, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 62}'),
	(133, '2021-02-25 09:02:24', 2, 248, 'MODERATED', 'Modération d\'une question', '{"question": 60, "moderated": 1}'),
	(134, '2021-02-25 09:02:24', 2, 247, 'MODERATED', 'Modération d\'une question', '{"question": 59, "moderated": 1}'),
	(135, '2021-02-25 09:02:24', 2, 250, 'MODERATED', 'Modération d\'une question', '{"question": 62, "moderated": 1}'),
	(136, '2021-02-25 09:02:24', 2, 249, 'MODERATED', 'Modération d\'une question', '{"question": 61, "moderated": 1}'),
	(137, '2021-02-25 09:02:35', 2, 229, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 3}'),
	(138, '2021-02-25 09:02:38', 2, 224, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 2}'),
	(139, '2021-02-25 09:02:38', 2, 221, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(140, '2021-02-25 09:02:41', 2, 235, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(141, '2021-02-25 09:02:41', 2, 240, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(142, '2021-02-25 09:02:41', 2, 236, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(143, '2021-02-25 09:02:44', 2, 231, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(144, '2021-02-25 09:02:50', 2, 212, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 2}'),
	(145, '2021-02-25 09:02:53', 2, 212, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 5}'),
	(146, '2021-02-25 09:02:53', 2, 230, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 4}'),
	(147, '2021-02-25 09:02:56', 2, 230, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 6}'),
	(148, '2021-02-25 09:02:59', 2, 225, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 4}'),
	(149, '2021-02-25 09:03:59', 2, 211, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 4}'),
	(150, '2021-02-25 09:04:44', 2, 222, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 3}'),
	(151, '2021-02-25 09:23:43', 2, 251, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 63}'),
	(152, '2021-02-25 09:23:50', 2, 251, 'MODERATED', 'Modération d\'une question', '{"question": 63, "moderated": 1}'),
	(153, '2021-02-25 09:24:33', 2, 251, 'LIKES', 'Ajout de like', '{"likes": 5, "totalLikes": 5}'),
	(154, '2021-02-25 09:24:36', 2, 251, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 7}'),
	(155, '2021-03-01 04:49:48', 37, 218, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(156, '2021-03-01 04:50:16', 37, 252, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 64}'),
	(157, '2021-03-01 04:51:06', 2, 252, 'MODERATED', 'Modération d\'une question', '{"question": 64, "moderated": 1}'),
	(158, '2021-03-01 04:51:27', 38, 252, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(159, '2021-03-01 04:54:53', 2, 253, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 65}'),
	(160, '2021-03-01 04:55:00', 2, 253, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 65}'),
	(161, '2021-03-01 06:13:18', 2, 242, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(162, '2021-03-01 06:13:33', 2, 233, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 4}'),
	(163, '2021-03-01 08:04:59', 2, 254, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 66}'),
	(164, '2021-03-01 08:05:15', 2, 254, 'MODERATED', 'Modération d\'une question', '{"question": 66, "moderated": 1}'),
	(165, '2021-03-01 08:15:53', 2, 255, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 68}'),
	(166, '2021-03-01 08:16:04', 2, 255, 'MODERATED', 'Modération d\'une question', '{"question": 68, "moderated": 1}'),
	(167, '2021-03-01 08:17:49', 2, 196, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 3}'),
	(168, '2021-03-01 08:18:00', 2, 196, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 4}'),
	(169, '2021-03-01 08:18:15', 2, 237, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(170, '2021-03-01 08:18:21', 2, 228, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(171, '2021-03-01 09:13:42', 2, 251, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 8}'),
	(172, '2021-03-01 19:46:54', 42, 256, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 69}'),
	(173, '2021-03-01 19:47:36', 2, 256, 'MODERATED', 'Modération d\'une question', '{"question": 69, "moderated": 1}'),
	(174, '2021-03-01 19:48:03', 2, 256, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 5}'),
	(175, '2021-03-01 19:48:03', 2, 256, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 5}'),
	(176, '2021-03-02 03:57:25', 43, 257, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 70}'),
	(177, '2021-03-02 03:57:33', 2, 257, 'MODERATED', 'Modération d\'une question', '{"question": 70, "moderated": 1}'),
	(178, '2021-03-02 03:57:47', 8, 257, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 2}'),
	(179, '2021-03-02 03:57:50', 8, 257, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 3}'),
	(180, '2021-03-02 03:57:57', 43, 243, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(181, '2021-03-02 03:58:00', 43, 257, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 4}'),
	(182, '2021-03-02 04:42:12', 43, 258, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 71}'),
	(183, '2021-03-02 04:42:35', 2, 258, 'MODERATED', 'Modération d\'une question', '{"question": 71, "moderated": 1}'),
	(184, '2021-03-02 04:42:45', 43, 258, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(185, '2021-03-02 05:41:04', 2, 192, 'SELECT', 'Sélection d\'une question', '{"question": 11, "selected": 1}'),
	(186, '2021-03-02 05:57:05', 2, 192, 'SELECT', 'Sélection d\'une question', '{"question": 11, "selected": 1}'),
	(187, '2021-03-02 05:57:58', 2, 192, 'SELECT', 'Désélection d\'une question', '{"question": 11, "selected": 0}'),
	(188, '2021-03-02 08:59:16', 8, 203, 'SELECT', 'Sélection d\'une question', '{"question": 16, "selected": 1}'),
	(189, '2021-03-02 08:59:24', 8, 203, 'SELECT', 'Désélection d\'une question', '{"question": 16, "selected": 0}'),
	(190, '2021-03-02 08:59:31', 8, 203, 'SELECT', 'Sélection d\'une question', '{"question": 16, "selected": 1}'),
	(191, '2021-03-02 08:59:35', 8, 203, 'SELECT', 'Désélection d\'une question', '{"question": 16, "selected": 0}'),
	(192, '2021-03-03 07:19:30', 2, 210, 'SELECT', 'Sélection d\'une question', '{"question": 22, "selected": 1}'),
	(193, '2021-03-03 07:19:35', 2, 210, 'SELECT', 'Désélection d\'une question', '{"question": 22, "selected": 0}'),
	(194, '2021-03-03 07:20:53', 2, 212, 'SELECT', 'Sélection d\'une question', '{"question": 24, "selected": 1}'),
	(195, '2021-03-03 07:20:57', 2, 256, 'SELECT', 'Sélection d\'une question', '{"question": 69, "selected": 1}'),
	(196, '2021-03-03 07:21:04', 2, 256, 'SELECT', 'Désélection d\'une question', '{"question": 69, "selected": 0}'),
	(197, '2021-03-03 07:21:09', 2, 212, 'SELECT', 'Désélection d\'une question', '{"question": 24, "selected": 0}'),
	(198, '2021-03-03 07:21:18', 2, 211, 'SELECT', 'Sélection d\'une question', '{"question": 23, "selected": 1}'),
	(199, '2021-03-03 07:21:22', 2, 211, 'SELECT', 'Désélection d\'une question', '{"question": 23, "selected": 0}'),
	(200, '2021-03-03 07:21:28', 2, 237, 'SELECT', 'Sélection d\'une question', '{"question": 49, "selected": 1}'),
	(201, '2021-03-03 07:21:31', 2, 237, 'SELECT', 'Désélection d\'une question', '{"question": 49, "selected": 0}'),
	(202, '2021-03-03 07:21:33', 2, 237, 'SELECT', 'Sélection d\'une question', '{"question": 49, "selected": 1}'),
	(203, '2021-03-03 07:21:33', 2, 237, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 49}'),
	(204, '2021-03-03 07:21:46', 2, 242, 'SELECT', 'Sélection d\'une question', '{"question": 54, "selected": 1}'),
	(205, '2021-03-03 07:21:56', 2, 242, 'SELECT', 'Désélection d\'une question', '{"question": 54, "selected": 0}'),
	(206, '2021-03-03 07:22:00', 2, 242, 'SELECT', 'Sélection d\'une question', '{"question": 54, "selected": 1}'),
	(207, '2021-03-03 07:22:04', 2, 242, 'SELECT', 'Désélection d\'une question', '{"question": 54, "selected": 0}'),
	(208, '2021-03-03 07:22:09', 2, 242, 'SELECT', 'Sélection d\'une question', '{"question": 54, "selected": 1}'),
	(209, '2021-03-03 07:22:18', 2, 236, 'SELECT', 'Sélection d\'une question', '{"question": 48, "selected": 1}'),
	(210, '2021-03-03 07:22:22', 2, 242, 'SELECT', 'Désélection d\'une question', '{"question": 54, "selected": 0}'),
	(211, '2021-03-03 07:22:24', 2, 242, 'SELECT', 'Sélection d\'une question', '{"question": 54, "selected": 1}'),
	(212, '2021-03-03 07:22:28', 2, 257, 'SELECT', 'Sélection d\'une question', '{"question": 70, "selected": 1}'),
	(213, '2021-03-03 07:24:06', 2, 257, 'SELECT', 'Désélection d\'une question', '{"question": 70, "selected": 0}'),
	(214, '2021-03-03 07:24:08', 2, 236, 'SELECT', 'Désélection d\'une question', '{"question": 48, "selected": 0}'),
	(215, '2021-03-03 07:24:10', 2, 242, 'SELECT', 'Désélection d\'une question', '{"question": 54, "selected": 0}'),
	(216, '2021-03-03 07:30:59', 2, 257, 'SELECT', 'Sélection d\'une question', '{"question": 70, "selected": 1}'),
	(217, '2021-03-03 07:30:59', 2, 236, 'SELECT', 'Sélection d\'une question', '{"question": 48, "selected": 1}'),
	(218, '2021-03-03 07:31:00', 2, 242, 'SELECT', 'Sélection d\'une question', '{"question": 54, "selected": 1}'),
	(219, '2021-03-03 07:31:20', 2, 236, 'SELECT', 'Désélection d\'une question', '{"question": 48, "selected": 0}'),
	(220, '2021-03-03 07:31:29', 2, 242, 'SELECT', 'Désélection d\'une question', '{"question": 54, "selected": 0}'),
	(221, '2021-03-03 07:31:32', 2, 257, 'SELECT', 'Désélection d\'une question', '{"question": 70, "selected": 0}'),
	(222, '2021-03-03 07:31:56', 44, 214, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 10}'),
	(223, '2021-03-03 07:32:29', 2, 222, 'SELECT', 'Sélection d\'une question', '{"question": 34, "selected": 1}'),
	(224, '2021-03-03 07:32:46', 2, 222, 'SELECT', 'Désélection d\'une question', '{"question": 34, "selected": 0}'),
	(225, '2021-03-03 07:32:51', 2, 222, 'SELECT', 'Sélection d\'une question', '{"question": 34, "selected": 1}'),
	(226, '2021-03-03 07:32:51', 2, 222, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 34}'),
	(227, '2021-03-03 07:32:55', 2, 205, 'SELECT', 'Sélection d\'une question', '{"question": 17, "selected": 1}'),
	(228, '2021-03-03 07:32:58', 2, 205, 'SELECT', 'Désélection d\'une question', '{"question": 17, "selected": 0}'),
	(229, '2021-03-03 07:33:01', 2, 229, 'SELECT', 'Sélection d\'une question', '{"question": 41, "selected": 1}'),
	(230, '2021-03-03 07:33:05', 2, 229, 'SELECT', 'Désélection d\'une question', '{"question": 41, "selected": 0}'),
	(231, '2021-03-03 07:33:05', 2, 229, 'SELECT', 'Sélection d\'une question', '{"question": 41, "selected": 1}'),
	(232, '2021-03-03 07:33:05', 2, 229, 'SELECT', 'Désélection d\'une question', '{"question": 41, "selected": 0}'),
	(233, '2021-03-03 07:33:05', 2, 229, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 6}'),
	(234, '2021-03-03 07:33:15', 2, 229, 'SUPPRESSED', 'Suppression d\'une question', '{"question": 41}'),
	(235, '2021-03-03 07:33:15', 2, 229, 'SELECT', 'Sélection d\'une question', '{"question": 41, "selected": 1}'),
	(236, '2021-03-03 07:33:23', 2, 224, 'SELECT', 'Sélection d\'une question', '{"question": 36, "selected": 1}'),
	(237, '2021-03-03 07:33:26', 2, 211, 'SELECT', 'Sélection d\'une question', '{"question": 23, "selected": 1}'),
	(238, '2021-03-03 09:19:13', 44, 259, 'QUESTION', 'Ajout d\'une question', '{"source": 0, "question": 72}'),
	(239, '2021-03-03 09:25:15', 9, 259, 'MODERATED', 'Modération d\'une question', '{"question": 72, "moderated": 1}'),
	(240, '2021-03-03 09:26:22', 44, 259, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(241, '2021-03-03 09:26:48', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(242, '2021-03-03 09:26:49', 2, 259, 'SELECT', 'Désélection d\'une question', '{"question": 72, "selected": 0}'),
	(243, '2021-03-03 09:26:49', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(244, '2021-03-03 09:26:49', 2, 259, 'SELECT', 'Désélection d\'une question', '{"question": 72, "selected": 0}'),
	(245, '2021-03-03 09:26:49', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(246, '2021-03-03 09:26:49', 2, 259, 'LIKES', 'Ajout de like', '{"likes": 5, "totalLikes": 6}'),
	(247, '2021-03-03 09:27:07', 2, 259, 'SELECT', 'Désélection d\'une question', '{"question": 72, "selected": 0}'),
	(248, '2021-03-03 09:27:10', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(249, '2021-03-03 09:27:11', 2, 259, 'SELECT', 'Désélection d\'une question', '{"question": 72, "selected": 0}'),
	(250, '2021-03-03 09:27:13', 2, 259, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 8}'),
	(251, '2021-03-03 09:28:34', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(252, '2021-03-03 09:28:34', 2, 259, 'SELECT', 'Désélection d\'une question', '{"question": 72, "selected": 0}'),
	(253, '2021-03-03 09:28:34', 2, 259, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 10}'),
	(254, '2021-03-03 09:28:47', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(255, '2021-03-03 09:28:49', 2, 259, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 11}'),
	(256, '2021-03-03 09:28:55', 2, 259, 'SELECT', 'Désélection d\'une question', '{"question": 72, "selected": 0}'),
	(257, '2021-03-03 09:32:09', 9, 260, 'QUESTION', 'Ajout d\'une question', '{"source": 1, "question": 73}'),
	(258, '2021-03-03 09:39:47', 9, 260, 'MODERATED', 'Modération d\'une question', '{"question": 73, "moderated": 1}'),
	(259, '2021-03-03 09:40:04', 44, 260, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(260, '2021-03-03 09:47:36', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(261, '2021-03-03 09:47:37', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(262, '2021-03-03 09:47:37', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(263, '2021-03-03 09:47:37', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(264, '2021-03-03 09:47:38', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(265, '2021-03-03 09:47:38', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(266, '2021-03-03 09:47:38', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(267, '2021-03-03 09:47:38', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(268, '2021-03-03 09:47:38', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(269, '2021-03-03 09:47:39', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(270, '2021-03-03 09:47:39', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(271, '2021-03-03 09:47:40', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(272, '2021-03-03 09:47:40', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(273, '2021-03-03 09:47:40', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(274, '2021-03-03 09:47:40', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(275, '2021-03-03 09:47:40', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(276, '2021-03-03 09:47:40', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(277, '2021-03-03 09:47:41', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(278, '2021-03-03 09:47:41', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(279, '2021-03-03 09:47:41', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(280, '2021-03-03 09:47:41', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(281, '2021-03-03 09:47:41', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(282, '2021-03-03 09:47:42', 2, 260, 'SELECT', 'Désélection d\'une question', '{"question": 73, "selected": 0}'),
	(283, '2021-03-03 09:47:42', 2, 260, 'LIKES', 'Ajout de like', '{"likes": 14, "totalLikes": 15}'),
	(284, '2021-03-03 09:47:42', 2, 260, 'SELECT', 'Sélection d\'une question', '{"question": 73, "selected": 1}'),
	(285, '2021-03-03 09:47:45', 2, 260, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 16}'),
	(286, '2021-03-03 09:52:51', 9, 261, 'QUESTION', 'Ajout d\'une question', '{"source": 1, "question": 74}'),
	(287, '2021-03-03 09:59:17', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 1}'),
	(288, '2021-03-03 10:04:48', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 2}'),
	(289, '2021-03-03 10:04:54', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 5}'),
	(290, '2021-03-03 10:04:57', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 13, "totalLikes": 18}'),
	(291, '2021-03-03 10:05:00', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 3, "totalLikes": 21}'),
	(292, '2021-03-03 10:05:09', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 4, "totalLikes": 25}'),
	(293, '2021-03-03 10:05:13', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 2, "totalLikes": 27}'),
	(294, '2021-03-03 10:05:15', 9, 261, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 28}'),
	(295, '2021-03-03 10:05:46', 9, 261, 'MODERATED', 'Modération d\'une question', '{"question": 74, "moderated": 1}'),
	(296, '2021-03-03 10:07:01', 9, 262, 'QUESTION', 'Ajout d\'une question', '{"source": 1, "question": 75}'),
	(297, '2021-03-03 10:07:08', 9, 262, 'LIKES', 'Ajout de like', '{"likes": 12, "totalLikes": 12}'),
	(298, '2021-03-03 10:07:11', 9, 262, 'LIKES', 'Ajout de like', '{"likes": 15, "totalLikes": 27}'),
	(299, '2021-03-03 10:07:17', 9, 262, 'LIKES', 'Ajout de like', '{"likes": 6, "totalLikes": 33}'),
	(300, '2021-03-03 10:07:20', 9, 262, 'LIKES', 'Ajout de like', '{"likes": 12, "totalLikes": 45}'),
	(301, '2021-03-03 10:07:30', 9, 262, 'MODERATED', 'Modération d\'une question', '{"question": 75, "moderated": 1}'),
	(302, '2021-03-03 10:09:34', 2, 214, 'SELECT', 'Sélection d\'une question', '{"question": 26, "selected": 1}'),
	(303, '2021-03-03 10:09:39', 2, 214, 'SELECT', 'Désélection d\'une question', '{"question": 26, "selected": 0}'),
	(304, '2021-03-03 10:09:43', 2, 259, 'SELECT', 'Sélection d\'une question', '{"question": 72, "selected": 1}'),
	(305, '2021-03-03 10:09:45', 2, 259, 'LIKES', 'Ajout de like', '{"likes": 1, "totalLikes": 12}');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;

-- Listage de la structure de la procédure moju. selectQuestion
DROP PROCEDURE IF EXISTS `selectQuestion`;
DELIMITER //
CREATE PROCEDURE `selectQuestion`(
	IN `id_evqust` MEDIUMINT,
	IN `id_user` MEDIUMINT
)
BEGIN
	DECLARE selected TINYINT(1) DEFAULT 0;
    DECLARE permissions INT DEFAULT 0;
    DECLARE id_question MEDIUMINT;
    SELECT e.selected, e.id_question
    FROM evqust AS e
    WHERE e.id = id_evqust
    INTO @selected,
    	 @id_question;
    SELECT u.permissions
    FROM users AS u
    WHERE u.id = id_user
    INTO @permissions;
    IF (@permissions & 2) = 2 THEN
      IF @selected = 1 THEN
			UPDATE evqust
			SET selected = 0
			WHERE id = id_evqust;
         INSERT INTO review(id_evqust, id_user, `date`, type, description, infos) VALUES (id_evqust, id_user, NOW(), 'SELECT', 'Désélection d\'une question', JSON_OBJECT('question', @id_question, 'selected', 0));
		ELSE
			UPDATE evqust
			SET selected = 1
			WHERE id = id_evqust;
         INSERT INTO review(id_evqust, id_user, `date`, type, description, infos) VALUES (id_evqust, id_user, NOW(), 'SELECT', 'Sélection d\'une question', JSON_OBJECT('question', @id_question, 'selected', 1));
		END IF;
    END IF;
END//
DELIMITER ;

-- Listage de la structure de la table moju. sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session` varchar(256) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime DEFAULT NULL,
  `id_user` mediumint NOT NULL,
  `id_event` mediumint NOT NULL,
  UNIQUE KEY `session` (`session`),
  KEY `id_user` (`id_user`),
  KEY `id_event` (`id_event`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`),
  CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`id_event`) REFERENCES `events` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.sessions : ~49 rows (environ)
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`session`, `date_start`, `date_end`, `id_user`, `id_event`) VALUES
	('00ea90817dcee3d17dce0ea52dc75d15', '2021-02-23 08:56:31', NULL, 6, 3),
	('02bb707505218fb4052a25ab8679dd45', '2021-02-12 09:19:44', '2021-02-25 08:46:31', 2, 3),
	('06322fc8ccce11cec03333858a20d737', '2021-02-23 05:35:54', '2021-02-23 05:35:58', 26, 3),
	('0c8d3bcf5153ab4c69cd2899d355e6ba', '2021-02-23 05:13:55', '2021-02-23 05:14:12', 25, 3),
	('12bfad536b321d4f61beebfbe5d70a7c', '2021-03-02 03:55:15', NULL, 2, 3),
	('12d333e50f03234cb22917fc9bd1ce66', '2021-02-25 08:46:58', '2021-02-25 08:47:45', 36, 3),
	('131e421d04276f21c8693385085bef94', '2021-03-01 04:54:39', NULL, 2, 3),
	('190375b5843cf776f9d19ece5c7c6a1b', '2021-02-23 08:57:09', '2021-02-23 08:57:12', 33, 3),
	('1eadd79fdb5e790772dc261044ff2758', '2021-03-01 08:14:51', '2021-03-01 08:15:03', 41, 3),
	('264fe86a5a3d711d1a8f471da45c13a5', '2021-02-23 06:56:25', '2021-02-25 08:46:31', 2, 3),
	('2a1c172dbf87e254e2492acc4f512003', '2021-03-03 09:18:39', NULL, 9, 3),
	('2f8d42f583c0b65f07616514029591af', '2021-02-25 06:32:10', '2021-02-25 06:33:10', 35, 3),
	('4175421ba03b3fc82d0593bd8296fb4c', '2021-02-25 08:48:05', NULL, 2, 3),
	('46491ed365efc87dfef31580cb3f75da', '2021-02-25 05:57:26', '2021-02-25 08:46:31', 2, 3),
	('4b2d272c3f8f151b3d0c369059133512', '2021-02-10 20:55:55', '2021-02-25 08:46:31', 2, 3),
	('54aa2cfe4e5bee2864d30e0f29ef15a5', '2021-02-10 20:52:40', NULL, 1, 3),
	('61104a5270ff7b7bd0a789357a3b3c04', '2021-03-01 04:49:38', '2021-03-01 04:50:26', 37, 3),
	('657da5b9bdcea94e4a1f162ebd9c9925', '2021-03-01 19:46:33', '2021-03-01 19:47:03', 42, 3),
	('6f5e785ddbda3127487763c5bb78b4a0', '2021-02-23 07:54:21', NULL, 30, 3),
	('6fcebba0e48b6c103454475e860de7e0', '2021-02-23 09:20:45', '2021-02-23 09:20:57', 11, 2),
	('74b53b32b316753e6e63cd9df0b927fb', '2021-03-01 19:47:28', NULL, 2, 3),
	('76b385f8510cb83e09f0ba68cdf2a034', '2021-02-23 05:56:57', '2021-02-23 05:57:01', 27, 3),
	('78cf4fe76120eaf39993d1475d8a8235', '2021-03-01 04:51:21', '2021-03-01 04:52:04', 38, 3),
	('7e0720e7d8018bab5426d244eee81e0a', '2021-03-03 07:19:01', NULL, 2, 3),
	('816549f0e4f45de11c40e238bb996e6f', '2021-02-23 09:08:48', '2021-02-25 05:56:34', 8, 3),
	('857ea86416c8799b88eab45a95f9736c', '2021-02-23 05:57:26', '2021-02-23 06:24:20', 28, 3),
	('867b5667da886b5ba762d29bdd215b55', '2021-03-01 07:19:52', NULL, 39, 3),
	('87cd757aa107200b0cd83b1fafb2830c', '2021-03-02 03:52:20', NULL, 43, 3),
	('941f66285cb6b4d5971a80fd098028be', '2021-02-23 08:56:12', NULL, 6, 3),
	('9b59ace900ac4ad5f19555447c476bc6', '2021-02-24 06:28:55', '2021-02-24 06:28:59', 34, 2),
	('9c80421733015db83eba496a542337ad', '2021-02-23 07:38:28', '2021-02-25 08:46:31', 2, 3),
	('a376ef176a065c999724ccf51f794c24', '2021-02-25 07:29:35', '2021-02-25 08:46:31', 2, 3),
	('a4dda80bfedb7a57898eb2f21b56d201', '2021-02-23 08:56:42', '2021-02-25 05:56:34', 8, 3),
	('a59bdc30b5b4608712ffa781fae05e18', '2021-02-25 05:56:28', '2021-02-25 05:56:34', 8, 3),
	('a9c381a2ff73a8324725ab6e55131afa', '2021-03-01 08:05:43', NULL, 40, 3),
	('b6f0acc236b23a1582a4ba6c9d0ff2b5', '2021-02-23 09:08:19', NULL, 6, 3),
	('ba1b9ce054637c14518c0aad6172d92b', '2021-03-01 04:50:58', NULL, 2, 3),
	('bd08580ebde032cc4453726d5a5820a7', '2021-02-23 08:02:12', '2021-02-23 08:02:15', 32, 3),
	('bd3ef845249b0f70c71472d47d026a40', '2021-02-23 09:08:20', NULL, 6, 3),
	('be713aba4fc9d9cc656eab9c1d76e4a1', '2021-02-23 07:54:28', NULL, 31, 3),
	('c0427d1e255fa57d5150ffcffba46aa1', '2021-03-03 07:20:49', NULL, 44, 3),
	('c643b13b112b51fe25e3e29f0b2a2ee7', '2021-02-22 07:27:21', '2021-02-22 07:29:03', 14, 3),
	('d2b8cfc2c290aac512a44544b8b9d0eb', '2021-03-03 09:07:29', NULL, 9, 3),
	('d2e77bcefeec3fba13e17d5bf8e8057a', '2021-03-03 09:08:31', NULL, 9, 3),
	('da206fc8e21916ff920c9dd2db8dfea2', '2021-02-23 06:24:31', NULL, 29, 3),
	('e89d2958b4ad094e5d5dee5ac5b89935', '2021-03-01 08:15:36', NULL, 2, 3),
	('f2a9b71c35302ab6715c762fc2351588', '2021-02-12 09:19:15', NULL, 1, 3),
	('fd4d1fbbada75ebf28e6b303d169154d', '2021-02-23 05:13:15', NULL, 24, 3),
	('fde77b1bb664a9448106e25bed6a4d03', '2021-03-02 03:56:46', NULL, 8, 3);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;

-- Listage de la structure de la table moju. users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `greetings` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(128) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `role` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'participant',
  `permissions` smallint NOT NULL DEFAULT '1',
  `infos` json DEFAULT NULL,
  `suppressed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Listage des données de la table moju.users : ~28 rows (environ)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `greetings`, `firstName`, `lastName`, `password`, `role`, `permissions`, `infos`, `suppressed`) VALUES
	(1, 'Mr.', 'Olivier', 'G.D.B.', 'pass', 'participant, animateur', 3, '{}', 0),
	(2, 'Mr.', 'Ronan', 'P.', 'pass', 'tous', 31, '{"id": 1}', 0),
	(5, 'Mr.', 'Olivier', 'C.', 'pass2', 'animateur', 2, '{}', 0),
	(6, 'Mr.', 'Olivier', 'A.', 'pass', 'admin', 8, '{}', 0),
	(8, 'Mr.', 'Olivier', 'M.', 'pass', 'participant, animateur', 3, '{"id": 1}', 0),
	(9, 'Mr.', 'Olivier', 'O.', 'pass', 'participant, client, modérateur', 13, '{"key": 1}', 0),
	(11, 'Mr.', 'Mathhieu', 'ADOR', 'pass', 'participant', 1, '{}', 0),
	(12, 'Mr.', 'béta', 'testeur', 'pass', 'participant', 1, '{}', 0),
	(13, 'Mr.', 'Ronan', 'testeur', 'pass', 'participant', 1, '{}', 0),
	(14, '', '', '', '', 'participant', 1, NULL, 0),
	(24, '', '', '', '', 'participant', 1, NULL, 0),
	(25, '', '', '', '', 'participant', 1, NULL, 0),
	(26, '', '', '', '', 'participant', 1, NULL, 0),
	(27, '', '', '', '', 'participant', 1, NULL, 0),
	(28, '', '', '', '', 'participant', 1, NULL, 0),
	(29, '', '', '', '', 'participant', 1, NULL, 0),
	(30, '', '', '', '', 'participant', 1, NULL, 0),
	(31, '', '', '', '', 'participant', 1, NULL, 0),
	(32, '', '', '', '', 'participant', 1, NULL, 0),
	(33, '', '', '', '', 'participant', 1, NULL, 0),
	(34, '', '', '', '', 'participant', 1, NULL, 0),
	(35, '', '', '', '', 'participant', 1, NULL, 0),
	(36, '', '', '', '', 'participant', 1, NULL, 0),
	(37, '', '', '', '', 'participant', 1, NULL, 0),
	(38, '', '', '', '', 'participant', 1, NULL, 0),
	(39, '', '', '', '', 'participant', 1, NULL, 0),
	(40, '', '', '', '', 'participant', 1, NULL, 0),
	(41, '', '', '', '', 'participant', 1, NULL, 0),
	(42, '', '', '', '', 'participant', 1, NULL, 0),
	(43, '', '', '', '', 'participant', 1, NULL, 0),
	(44, '', '', '', '', 'participant', 1, NULL, 0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Listage de la structure de la fonction moju. verifyUser
DROP FUNCTION IF EXISTS `verifyUser`;
DELIMITER //
CREATE FUNCTION `verifyUser`(
	`firstName` VARCHAR(50),
	`lastName` VARCHAR(50),
	`id_event` INT
) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
BEGIN
	DECLARE cur_date DATETIME;
	DECLARE res TINYINT(1) DEFAULT 0;
	DECLARE new_s VARCHAR(256);
	DECLARE id_user MEDIUMINT;
    IF (SELECT EXISTS(SELECT * FROM users AS u
        WHERE u.firstName = firstName AND u.lastName = lastName)) THEN
        SELECT id FROM users AS u
        WHERE u.firstName = firstName AND u.lastName = lastName
        INTO @id_user;
      SET @cur_date = NOW();
      SET @new_s = MD5(CONCAT("Bienvenue sur le site - user ", firstName, " ", lastName, " il est ", @cur_date));
    	INSERT INTO sessions(`session`, date_start, id_user, id_event) VALUES(@new_s, @cur_date, @id_user, id_event);
	   RETURN @new_s;
	 ELSE
	   RETURN '';
    END IF;
END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
